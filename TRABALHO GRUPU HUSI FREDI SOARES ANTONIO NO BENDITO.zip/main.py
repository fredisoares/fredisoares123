

# Hatama valor ba variavel x
x = int(input("Hatama valor ba x: "))

# Uza if statement atu verifika kondisaun
if x == 10:
    y = 5
    print("x igual ho 10, entaun y =", y)

# Else — sei hala'o bainhira kondisaun la verdade
else:
    y = 0
    print("x la'os 10, entaun y =", y)

# Print mensajen final
print("Programa remata ho susesu!")
